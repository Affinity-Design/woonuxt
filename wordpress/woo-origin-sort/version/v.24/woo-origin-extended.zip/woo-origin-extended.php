<?php
/*
Plugin Name: Woo Origin – List & Analytics Filters
Description: Adds a sortable + filterable "Origin" column to WooCommerce Orders list and to Analytics → Orders.
Author: Affinity Design – Paul Giovanatto
Version: 2.4
Requires Plugins: woocommerce
*/

defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Utilities\OrderUtil;

/* ───────────────────────── CONFIG ───────────────────────── */
const PG_ORIGIN_META_KEY = '_wc_order_attribution_utm_source'; // change if your store uses another key

/* ─────────────────────── HELPERS ────────────────────────── */
function pg_is_hpos(): bool {
	return class_exists( OrderUtil::class ) && OrderUtil::custom_orders_table_usage_is_enabled();
}

function pg_get_all_origins(): array {
	global $wpdb;
	$table = pg_is_hpos() ? $wpdb->prefix . 'wc_orders_meta' : $wpdb->postmeta;

	return $wpdb->get_col(
		$wpdb->prepare(
			"SELECT DISTINCT meta_value
			 FROM {$table}
			 WHERE meta_key = %s AND meta_value <> ''
			 ORDER BY meta_value",
			PG_ORIGIN_META_KEY
		)
	);
}

/* ═══════════════════════════════════════════════════════════
 *  PART A  –  ORDERS LIST TABLE  (legacy + HPOS, Woo 9.x)
 * ═════════════════════════════════════════════════════════ */
# 1 ▸ Column (legacy support for your setup)
add_filter( 'manage_edit-shop_order_columns', function ( $cols ) {
	$pos   = array_search( 'order_total', array_keys( $cols ), true );
	$front = array_slice( $cols, 0, $pos, true );
	$after = array_slice( $cols, $pos, null, true );
	$front['origin_sort'] = __( 'Origin', 'woocommerce' );
	return $front + $after;
}, 20 );

# 2 ▸ Cell content (legacy support)
add_action( 'manage_shop_order_posts_custom_column', function ( $column, $post_id ) {
	if ( 'origin_sort' !== $column ) {
		return;
	}
	$order = wc_get_order( $post_id );
	if ( ! $order ) {
		return;
	}
	$val = (string) $order->get_meta( PG_ORIGIN_META_KEY, true );
	echo esc_html( $val !== '' ? $val : __( 'Unknown', 'woocommerce' ) );
}, 20, 2 );

# 3 ▸ Sortable heading (legacy support)
add_filter( 'manage_edit-shop_order_sortable_columns', function ( $cols ) {
	$cols['origin_sort'] = 'origin_sort';
	return $cols;
}, 20 );

# 4 ▸ Toolbar drop-down (legacy support)
add_action( 'restrict_manage_posts', function ( $post_type ) {
	if ( 'shop_order' !== $post_type ) {
		return;
	}

	$selected = isset( $_GET['pg_origin'] ) ? sanitize_text_field( wp_unslash( $_GET['pg_origin'] ) ) : '';
	echo '<select name="pg_origin" style="max-width:150px;margin-left:8px;">';
	echo '<option value="">' . esc_html__( 'All origins', 'woocommerce' ) . '</option>';

	foreach ( pg_get_all_origins() as $origin ) {
		printf(
			'<option value="%1$s"%3$s>%2$s</option>',
			esc_attr( $origin ),
			esc_html( $origin ),
			selected( $selected, $origin, false )
		);
	}
	echo '</select>';
}, 20 );

# 5 ▸ Query handling (filtering and sorting)
add_action( 'pre_get_posts', function ( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}

	$screen = get_current_screen();
	if ( ! $screen || $screen->id !== 'edit-shop_order' ) {
		return;
	}

	// Handle filtering by origin
	if ( ! empty( $_GET['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( wp_unslash( $_GET['pg_origin'] ) );
		
		$query->set( 'meta_query', array(
			array(
				'key'   => PG_ORIGIN_META_KEY,
				'value' => $origin_value,
				'compare' => '='
			)
		));
	}

	// Handle sorting by origin
	if ( isset( $_GET['orderby'] ) && $_GET['orderby'] === 'origin_sort' ) {
		$order = isset( $_GET['order'] ) && strtoupper( $_GET['order'] ) === 'DESC' ? 'DESC' : 'ASC';
		
		$query->set( 'meta_key', PG_ORIGIN_META_KEY );
		$query->set( 'orderby', 'meta_value' );
		$query->set( 'order', $order );
	}
} );

/* ═══════════════════════════════════════════════════════════
 *  PART B  –  ANALYTICS → ORDERS  (wc-admin React screen)
 * ═════════════════════════════════════════════════════════ */
# 1 ▸ REST query filter
add_filter( 'woocommerce_analytics_orders_query_args', function ( $args, $request ) {
	if ( ! empty( $request['pg_origin'] ) ) {
		$args['meta_key']   = PG_ORIGIN_META_KEY;
		$args['meta_value'] = sanitize_text_field( $request['pg_origin'] );
	}
	return $args;
}, 10, 2 );

# 2 ▸ Enqueue our React snippet + data
add_action( 'admin_enqueue_scripts', function () {
	if ( empty( $_GET['page'] ) || 'wc-admin' !== $_GET['page'] ) {
		return;
	}

	/* 2a. the script itself FIRST */
	wp_enqueue_script(
		'pg-origin-analytics-filter',
		plugins_url( 'filter.js', __FILE__ ),
		[ 'wc-admin-app', 'wp-hooks', 'wp-element', 'wp-components' ],
		'2.4',
		true
	);

	/* 2b. origin list for JS AFTER enqueuing */
	$origins_data = array_map(
		function( $o ) { return [ 'value' => $o, 'label' => $o ]; },
		pg_get_all_origins()
	);
	
	wp_localize_script(
		'pg-origin-analytics-filter',
		'pgOriginData',
		$origins_data
	);

	// Add debugging for analytics
	wp_add_inline_script(
		'pg-origin-analytics-filter',
		'console.log("PG Origin Plugin: Script loaded, origins data:", ' . wp_json_encode( $origins_data ) . ');',
		'before'
	);
} );
