/* WooCommerce Analytics → Orders — add an "Origin" advanced filter */
(function () {
  "use strict";

  // Check if required dependencies are available
  if (typeof wp === "undefined" || !wp.hooks || !wp.element || !wp.components) {
    console.error(
      "PG-Origin filter: Required WordPress dependencies not available"
    );
    return;
  }

  const { addFilter } = wp.hooks;
  const { createElement } = wp.element;
  const { SelectControl } = wp.components;

  // Check if pgOriginData is available
  if (typeof pgOriginData === "undefined") {
    console.warn("PG-Origin filter: Origin data not available");
    return;
  }

  console.info("PG-Origin filter loaded"); /* ← see this in DevTools */

  addFilter(
    "woocommerce_admin_analytics_orders_filters",
    "pg-origin/extend",
    (filters) => [
      ...filters,
      {
        label: "Origin",
        staticParams: ["pg_origin"],
        param: "pg_origin",
        showFilters: () => true,
        Component: ({ param, paramValue, update }) =>
          createElement(SelectControl, {
            label: "Origin",
            value: paramValue || "",
            options: [{ label: "All", value: "" }, ...pgOriginData],
            onChange: (v) => update({ [param]: v }),
          }),
      },
    ]
  );
})();
