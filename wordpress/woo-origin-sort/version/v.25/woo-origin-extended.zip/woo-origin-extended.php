<?php
/*
Plugin Name: Origin List & Analytics Filters
Description: Adds a sortable + filterable "Origin" column to WooCommerce Orders list and to Analytics → Orders.
Author: Affinity Design – Paul Giovanatto
Version: 2.5
Requires Plugins: woocommerce
*/

defined( 'ABSPATH' ) || exit;

/* ───────────────────────── CONFIG ───────────────────────── */
const PG_ORIGIN_META_KEY = '_wc_order_attribution_utm_source'; // change if your store uses another key

/* ─────────────────────── HELPERS ────────────────────────── */

function pg_get_all_origins(): array {
	global $wpdb;
	// Legacy (post-based) order storage only
	$table = $wpdb->postmeta;

	return $wpdb->get_col(
		$wpdb->prepare(
			"SELECT DISTINCT meta_value
			 FROM {$table}
			 WHERE meta_key = %s AND meta_value <> ''
			 ORDER BY meta_value",
			PG_ORIGIN_META_KEY
		)
	);
}

/* ═══════════════════════════════════════════════════════════
 *  PART A  –  ORDERS LIST TABLE  (legacy + HPOS, Woo 9.x)
 * ═════════════════════════════════════════════════════════ */
# 1 ▸ Column (legacy support for your setup)
add_filter( 'manage_edit-shop_order_columns', function ( $cols ) {
	$pos   = array_search( 'order_total', array_keys( $cols ), true );
	$front = array_slice( $cols, 0, $pos, true );
	$after = array_slice( $cols, $pos, null, true );
	$front['origin_sort'] = __( 'Origin', 'woocommerce' );
	return $front + $after;
}, 20 );

# 2 ▸ Cell content (legacy support)
add_action( 'manage_shop_order_posts_custom_column', function ( $column, $post_id ) {
	if ( 'origin_sort' !== $column ) {
		return;
	}
	$order = wc_get_order( $post_id );
	if ( ! $order ) {
		return;
	}
	$val = (string) $order->get_meta( PG_ORIGIN_META_KEY, true );
	echo esc_html( $val !== '' ? $val : __( 'Unknown', 'woocommerce' ) );
}, 20, 2 );

# 3 ▸ Sortable heading (legacy support)
add_filter( 'manage_edit-shop_order_sortable_columns', function ( $cols ) {
	$cols['origin_sort'] = 'origin_sort';
	return $cols;
}, 20 );

# 4 ▸ Toolbar drop-down (legacy support)
add_action( 'restrict_manage_posts', function ( $post_type ) {
	if ( 'shop_order' !== $post_type ) {
		return;
	}

	$selected = isset( $_GET['pg_origin'] ) ? sanitize_text_field( wp_unslash( $_GET['pg_origin'] ) ) : '';
	echo '<select name="pg_origin" style="max-width:150px;margin-left:8px;">';
	echo '<option value="">' . esc_html__( 'All origins', 'woocommerce' ) . '</option>';

	foreach ( pg_get_all_origins() as $origin ) {
		printf(
			'<option value="%1$s"%3$s>%2$s</option>',
			esc_attr( $origin ),
			esc_html( $origin ),
			selected( $selected, $origin, false )
		);
	}
	echo '</select>';
}, 20 );

# 5 ▸ Query handling (filtering and sorting)
add_action( 'pre_get_posts', function ( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}

	$screen = get_current_screen();
	if ( ! $screen || $screen->id !== 'edit-shop_order' ) {
		return;
	}

	// Handle filtering by origin
	if ( ! empty( $_GET['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( wp_unslash( $_GET['pg_origin'] ) );
		
		$query->set( 'meta_query', array(
			array(
				'key'   => PG_ORIGIN_META_KEY,
				'value' => $origin_value,
				'compare' => '='
			)
		));
	}

	// Handle sorting by origin
	if ( isset( $_GET['orderby'] ) && $_GET['orderby'] === 'origin_sort' ) {
		$order = isset( $_GET['order'] ) && strtoupper( $_GET['order'] ) === 'DESC' ? 'DESC' : 'ASC';
		
		$query->set( 'meta_key', PG_ORIGIN_META_KEY );
		$query->set( 'orderby', 'meta_value' );
		$query->set( 'order', $order );
	}
} );

/* ═══════════════════════════════════════════════════════════
 *  PART B  –  ANALYTICS → ORDERS  (wc-admin React screen)
 * ═════════════════════════════════════════════════════════ */
# 1 ▸ REST query filters for Analytics
add_filter( 'woocommerce_analytics_orders_query_args', function ( $args, $request ) {
	if ( ! empty( $request['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $request['pg_origin'] );
		
		// Add meta query for origin filtering
		if ( ! isset( $args['meta_query'] ) ) {
			$args['meta_query'] = array();
		}
		
		$args['meta_query'][] = array(
			'key'     => PG_ORIGIN_META_KEY,
			'value'   => $origin_value,
			'compare' => '='
		);
		
		error_log( "PG Origin Plugin: Applied analytics filter for origin: {$origin_value}" );
	}
	return $args;
}, 10, 2 );

# Also support the reports query args filter
add_filter( 'woocommerce_analytics_orders_select_query', function ( $query, $args ) {
	if ( ! empty( $args['pg_origin'] ) ) {
		error_log( "PG Origin Plugin: Analytics select query filter triggered for origin: " . $args['pg_origin'] );
	}
	return $query;
}, 10, 2 );

# Handle REST API parameters for Analytics
add_filter( 'rest_shop_order_query', function ( $args, $request ) {
	if ( ! empty( $request['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $request['pg_origin'] );
		
		if ( ! isset( $args['meta_query'] ) ) {
			$args['meta_query'] = array();
		}
		
		$args['meta_query'][] = array(
			'key'     => PG_ORIGIN_META_KEY,
			'value'   => $origin_value,
			'compare' => '='
		);
		
		error_log( "PG Origin Plugin: Applied REST API filter for origin: {$origin_value}" );
	}
	return $args;
}, 10, 2 );

# Handle WooCommerce Analytics REST API endpoints
add_action( 'rest_api_init', function () {
	// Register the origin parameter for analytics endpoints
	register_rest_field( 'shop_order', 'pg_origin', array(
		'get_callback' => function ( $order ) {
			$order_obj = wc_get_order( $order['id'] );
			return $order_obj ? $order_obj->get_meta( PG_ORIGIN_META_KEY ) : '';
		},
		'schema' => array(
			'description' => __( 'Order origin source', 'woocommerce' ),
			'type'        => 'string',
			'context'     => array( 'view', 'edit' ),
		),
	) );
} );

# 2 ▸ Enqueue our React snippet + data
add_action( 'admin_enqueue_scripts', function () {
	// Check if we're on WooCommerce Analytics pages
	$current_screen = get_current_screen();
	if ( ! $current_screen || 
		 ( empty( $_GET['page'] ) || strpos( $_GET['page'], 'wc-' ) !== 0 ) &&
		 ( ! $current_screen || strpos( $current_screen->id, 'woocommerce' ) === false ) ) {
		return;
	}

	// Get origins data
	$origins_data = array_map(
		function( $o ) { return [ 'value' => $o, 'label' => $o ]; },
		pg_get_all_origins()
	);

	// Only enqueue if we have origin data
	if ( empty( $origins_data ) ) {
		error_log( 'PG Origin Plugin: No origin data found, not loading analytics filter' );
		return;
	}

	error_log( 'PG Origin Plugin: Enqueuing analytics script for page: ' . ( $_GET['page'] ?? 'unknown' ) );

	/* 2a. Enqueue the correct advanced filter implementation */
	// Main advanced filter (using correct hook from WC docs)
	wp_enqueue_script(
		'pg-origin-advanced-filter',
		plugins_url( 'advanced-filter.js', __FILE__ ),
		[ 'wp-hooks', 'wp-i18n' ],
		'2.5.1',
		true
	);

	// Diagnostic script for troubleshooting
	wp_enqueue_script(
		'pg-origin-diagnostic',
		plugins_url( 'diagnostic.js', __FILE__ ),
		[ 'wp-hooks' ],
		'2.5.1',
		true
	);

	/* 2b. Localize data for the focused scripts */
	$scripts = [ 'pg-origin-advanced-filter', 'pg-origin-diagnostic' ];
	foreach ( $scripts as $script ) {
		wp_localize_script( $script, 'pgOriginData', $origins_data );
	}

	// Add debugging for the advanced filter
	wp_add_inline_script(
		'pg-origin-advanced-filter',
		'console.log("PG Origin Plugin PHP: Advanced filter script enqueued");
		 console.log("PG Origin Plugin PHP: Origins data:", ' . wp_json_encode( $origins_data ) . ');
		 console.log("PG Origin Plugin PHP: Current page:", ' . wp_json_encode( $_GET['page'] ?? 'unknown' ) . ');
		 console.log("PG Origin Plugin PHP: Using CORRECT hook: woocommerce_admin_orders_report_filters");',
		'before'
	);
}, 20 ); // Load after WooCommerce Admin
