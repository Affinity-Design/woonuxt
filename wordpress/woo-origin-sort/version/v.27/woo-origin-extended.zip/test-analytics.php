<?php
/**
 * Test script for WooCommerce Analytics Origin Filter
 * 
 * Usage: Place this file in your WordPress root and access it directly
 * or use WP CLI: wp eval-file test-analytics.php
 */

// Load WordPress
if ( ! defined( 'ABSPATH' ) ) {
	require_once( dirname( __FILE__ ) . '/wp-load.php' );
}

// Check if WooCommerce is active
if ( ! class_exists( 'WooCommerce' ) ) {
	die( 'WooCommerce is not active.' );
}

echo "=== WooCommerce Analytics Origin Filter Test ===\n\n";

// 1. Check if analytics tables exist
global $wpdb;
$stats_table = $wpdb->prefix . 'wc_order_stats';
$table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $stats_table ) ) === $stats_table;

echo "1. Analytics Tables Check:\n";
echo "   - Table '{$stats_table}': " . ( $table_exists ? "EXISTS ✓" : "NOT FOUND ✗" ) . "\n\n";

// 2. Check for orders with origin data
$origin_count = $wpdb->get_var( $wpdb->prepare(
	"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != ''",
	'_wc_order_attribution_utm_source'
) );

echo "2. Origin Data Check:\n";
echo "   - Orders with origin data: {$origin_count}\n\n";

// 3. Get sample origins
$sample_origins = $wpdb->get_col( $wpdb->prepare(
	"SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value != '' LIMIT 5",
	'_wc_order_attribution_utm_source'
) );

echo "3. Sample Origins:\n";
foreach ( $sample_origins as $origin ) {
	echo "   - {$origin}\n";
}
echo "\n";

// 4. Test a sample query
if ( $table_exists && ! empty( $sample_origins ) ) {
	$test_origin = $sample_origins[0];
	echo "4. Testing SQL Query for origin: '{$test_origin}'\n";
	
	$test_query = "
		SELECT COUNT(*) 
		FROM {$stats_table} 
		LEFT JOIN {$wpdb->postmeta} AS origin_postmeta ON {$stats_table}.order_id = origin_postmeta.post_id
		WHERE origin_postmeta.meta_key = '_wc_order_attribution_utm_source' 
		AND origin_postmeta.meta_value = %s
	";
	
	$result = $wpdb->get_var( $wpdb->prepare( $test_query, $test_origin ) );
	echo "   - Orders found: " . ( $result !== null ? $result : "ERROR" ) . "\n";
	
	if ( $wpdb->last_error ) {
		echo "   - SQL Error: " . $wpdb->last_error . "\n";
	}
}

echo "\n5. REST API Endpoints:\n";
echo "   - Orders: " . rest_url( 'wc-analytics/reports/orders' ) . "\n";
echo "   - Stats: " . rest_url( 'wc-analytics/reports/orders/stats' ) . "\n";

echo "\n=== Test Complete ===\n";
