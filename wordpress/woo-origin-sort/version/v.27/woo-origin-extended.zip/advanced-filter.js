/* WooCommerce Analytics Orders Origin Filter - Advanced Filters Implementation */
(function () {
  "use strict";

  console.log("=== PG ORIGIN ADVANCED FILTER START ===");

  function initAdvancedOriginFilter() {
    // Check for required dependencies
    if (typeof wp === "undefined" || !wp.hooks || !wp.element || !wp.i18n) {
      console.log("PG-Origin Advanced: Dependencies not ready, retrying...");
      setTimeout(initAdvancedOriginFilter, 200);
      return;
    }

    // Check for origin data
    if (typeof pgOriginData === "undefined") {
      console.warn("PG-Origin Advanced: Origin data not available");
      return;
    }

    const { addFilter } = wp.hooks;
    const { __ } = wp.i18n;

    console.log("PG-Origin Advanced: All dependencies ready");
    console.log("PG-Origin Advanced: Origin data available:", pgOriginData);

    // Use the CORRECT hook name from WooCommerce documentation
    addFilter(
      "woocommerce_admin_orders_report_filters",
      "pg-origin/add-origin-filter",
      function (filters) {
        console.log(
          "🎯 CORRECT HOOK TRIGGERED: woocommerce_admin_orders_report_filters"
        );
        console.log("Existing filters:", filters);

        // Create our origin filter following the exact pattern from WC docs
        const originFilter = {
          label: __("Origin", "woocommerce"),
          staticParams: [],
          param: "pg_origin",
          showFilters: () => true,
          defaultValue: "",
          filters: pgOriginData.map((origin) => ({
            value: origin.value,
            label: origin.label,
            // Properly encode the value to handle special characters
            path: [`pg_origin=${encodeURIComponent(origin.value)}`],
          })),
        };

        console.log("PG-Origin Advanced: Adding origin filter:", originFilter);

        // Add our filter to the existing filters array
        return [originFilter, ...filters];
      }
    );

    // Also register as advanced filter for the new UI structure
    addFilter(
      "woocommerce_admin_analytics_orders_advanced_filters",
      "pg-origin/add-advanced-origin-filter",
      function (filters) {
        console.log("🎯 ADVANCED FILTERS HOOK TRIGGERED");
        console.log("Advanced filters received:", filters);

        const advancedOriginFilter = {
          title: __("Origin", "woocommerce"),
          filters: {
            pg_origin: {
              allowMultiple: false,
              labels: {
                add: __("Order Origin", "woocommerce"),
                placeholder: __("Select origin", "woocommerce"),
                rule: __("Origin is", "woocommerce"),
                title: __("Origin: {{filter}}", "woocommerce"),
                filter: "{{filter}}",
              },
              rules: [
                {
                  value: "is",
                  label: __("Is", "woocommerce"),
                },
              ],
              input: {
                component: "SelectControl",
                options: [
                  { label: __("All origins", "woocommerce"), value: "" },
                  ...pgOriginData,
                ],
              },
            },
          },
        };

        console.log(
          "PG-Origin Advanced: Adding advanced filter:",
          advancedOriginFilter
        );

        return {
          ...filters,
          pg_origin: advancedOriginFilter,
        };
      }
    );

    console.log("PG-Origin Advanced: Filter registration complete");
  }

  // Initialize when ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAdvancedOriginFilter);
  } else {
    initAdvancedOriginFilter();
  }
})();
