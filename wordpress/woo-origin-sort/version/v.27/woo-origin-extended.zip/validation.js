/* WooCommerce Analytics Origin Filter - Final Validation Script */
(function () {
  "use strict";

  console.log("=== PG ORIGIN FINAL VALIDATION ===");

  // Wait for page load and WooCommerce admin to be ready
  function validateFilter() {
    console.log("🔍 Starting validation...");

    // Check if we're on the Analytics Orders page
    const currentPage = new URLSearchParams(window.location.search).get("page");
    const isAnalyticsOrders =
      currentPage === "wc-admin" &&
      window.location.hash.includes("analytics/orders");

    console.log("📊 Current page:", currentPage);
    console.log("📈 Analytics Orders page:", isAnalyticsOrders);

    // Check if WordPress and WooCommerce objects are available
    const wpReady = typeof wp !== "undefined" && wp.hooks;
    const wcReady = typeof wc !== "undefined";
    console.log("🔧 WordPress ready:", wpReady);
    console.log("🛒 WooCommerce ready:", wcReady);

    // Check if our origin data is available
    const originDataReady =
      typeof pgOriginData !== "undefined" && Array.isArray(pgOriginData);
    console.log(
      "📋 Origin data ready:",
      originDataReady,
      pgOriginData?.length || 0,
      "items"
    );

    // Try to find filter elements in the DOM
    setTimeout(() => {
      const filterElements = document.querySelectorAll(
        '[class*="filter"], [class*="advanced"]'
      );
      console.log("🎛️ Filter elements found:", filterElements.length);

      // Look for our specific origin filter
      const originFilter = Array.from(filterElements).find(
        (el) =>
          el.textContent?.toLowerCase().includes("origin") ||
          el.innerHTML?.toLowerCase().includes("origin")
      );

      if (originFilter) {
        console.log("✅ Origin filter element found:", originFilter);
      } else {
        console.log("❌ Origin filter element not found");
      }

      // Check for any error messages
      const errorElements = document.querySelectorAll(
        '[class*="error"], [class*="notice-error"]'
      );
      if (errorElements.length > 0) {
        console.log("⚠️ Error elements found:", errorElements.length);
        errorElements.forEach((el) => console.log("Error:", el.textContent));
      }

      // Try to trigger a test filter request
      if (isAnalyticsOrders && originDataReady && pgOriginData.length > 0) {
        console.log(
          "🧪 Testing filter with first origin:",
          pgOriginData[0].value
        );

        // Create a test URL with the origin parameter
        const testUrl = new URL(window.location);
        testUrl.searchParams.set("pg_origin", pgOriginData[0].value);

        console.log("🔗 Test URL would be:", testUrl.toString());
        console.log(
          "ℹ️ To test manually, add '&pg_origin=" +
            encodeURIComponent(pgOriginData[0].value) +
            "' to the URL"
        );
      }
    }, 2000);

    // Monitor for any network requests to analytics endpoints
    if (window.fetch) {
      const originalFetch = window.fetch;
      window.fetch = function (...args) {
        const url = args[0];
        if (
          typeof url === "string" &&
          url.includes("/wc-analytics/reports/orders")
        ) {
          console.log("📡 Analytics API request detected:", url);

          // Check if our parameter is included
          if (url.includes("pg_origin=")) {
            const matches = url.match(/pg_origin=([^&]*)/);
            if (matches) {
              console.log(
                "✅ Origin parameter found in request:",
                decodeURIComponent(matches[1])
              );
            }
          }
        }
        return originalFetch.apply(this, args);
      };
    }
  }

  // Run validation
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", validateFilter);
  } else {
    validateFilter();
  }

  // Also run after a delay to catch dynamic content
  setTimeout(validateFilter, 3000);
  setTimeout(validateFilter, 5000);
})();
