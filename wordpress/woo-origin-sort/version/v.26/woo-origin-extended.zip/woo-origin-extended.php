<?php
/*
Plugin Name: Origin List & Analytics Filters
Description: Adds a sortable + filterable "Origin" column to WooCommerce Orders list and to Analytics → Orders.
Author: Affinity Design – Paul Giovanatto
Version: 2.6
Requires Plugins: woocommerce
*/

defined( 'ABSPATH' ) || exit;

/* ───────────────────────── CONFIG ───────────────────────── */
const PG_ORIGIN_META_KEY = '_wc_order_attribution_utm_source'; // change if your store uses another key

/* ─────────────────────── HELPERS ────────────────────────── */

function pg_get_all_origins(): array {
	global $wpdb;
	// Legacy (post-based) order storage only
	$table = $wpdb->postmeta;

	return $wpdb->get_col(
		$wpdb->prepare(
			"SELECT DISTINCT meta_value
			 FROM {$table}
			 WHERE meta_key = %s AND meta_value <> ''
			 ORDER BY meta_value",
			PG_ORIGIN_META_KEY
		)
	);
}

/* ═══════════════════════════════════════════════════════════
 *  PART A  –  ORDERS LIST TABLE  (legacy + HPOS, Woo 9.x)
 * ═════════════════════════════════════════════════════════ */
# 1 ▸ Column (legacy support for your setup)
add_filter( 'manage_edit-shop_order_columns', function ( $cols ) {
	$pos   = array_search( 'order_total', array_keys( $cols ), true );
	$front = array_slice( $cols, 0, $pos, true );
	$after = array_slice( $cols, $pos, null, true );
	$front['origin_sort'] = __( 'Origin', 'woocommerce' );
	return $front + $after;
}, 20 );

# 2 ▸ Cell content (legacy support)
add_action( 'manage_shop_order_posts_custom_column', function ( $column, $post_id ) {
	if ( 'origin_sort' !== $column ) {
		return;
	}
	$order = wc_get_order( $post_id );
	if ( ! $order ) {
		return;
	}
	$val = (string) $order->get_meta( PG_ORIGIN_META_KEY, true );
	echo esc_html( $val !== '' ? $val : __( 'Unknown', 'woocommerce' ) );
}, 20, 2 );

# 3 ▸ Sortable heading (legacy support)
add_filter( 'manage_edit-shop_order_sortable_columns', function ( $cols ) {
	$cols['origin_sort'] = 'origin_sort';
	return $cols;
}, 20 );

# 4 ▸ Toolbar drop-down (legacy support)
add_action( 'restrict_manage_posts', function ( $post_type ) {
	if ( 'shop_order' !== $post_type ) {
		return;
	}

	$selected = isset( $_GET['pg_origin'] ) ? sanitize_text_field( wp_unslash( $_GET['pg_origin'] ) ) : '';
	echo '<select name="pg_origin" style="max-width:150px;margin-left:8px;">';
	echo '<option value="">' . esc_html__( 'All origins', 'woocommerce' ) . '</option>';

	foreach ( pg_get_all_origins() as $origin ) {
		printf(
			'<option value="%1$s"%3$s>%2$s</option>',
			esc_attr( $origin ),
			esc_html( $origin ),
			selected( $selected, $origin, false )
		);
	}
	echo '</select>';
}, 20 );

# 5 ▸ Query handling (filtering and sorting)
add_action( 'pre_get_posts', function ( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}

	$screen = get_current_screen();
	if ( ! $screen || $screen->id !== 'edit-shop_order' ) {
		return;
	}

	// Handle filtering by origin
	if ( ! empty( $_GET['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( wp_unslash( $_GET['pg_origin'] ) );
		
		$query->set( 'meta_query', array(
			array(
				'key'   => PG_ORIGIN_META_KEY,
				'value' => $origin_value,
				'compare' => '='
			)
		));
	}

	// Handle sorting by origin
	if ( isset( $_GET['orderby'] ) && $_GET['orderby'] === 'origin_sort' ) {
		$order = isset( $_GET['order'] ) && strtoupper( $_GET['order'] ) === 'DESC' ? 'DESC' : 'ASC';
		
		$query->set( 'meta_key', PG_ORIGIN_META_KEY );
		$query->set( 'orderby', 'meta_value' );
		$query->set( 'order', $order );
	}
} );

/* ═══════════════════════════════════════════════════════════
 *  PART B  –  ANALYTICS → ORDERS  (wc-admin React screen)
 * ═════════════════════════════════════════════════════════ */
# 1 ▸ REST query filters for Analytics - FIXED APPROACH
add_filter( 'woocommerce_analytics_orders_query_args', function ( $args, $request ) {
	if ( ! empty( $request['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $request['pg_origin'] );
		
		// Add the parameter to query args for caching purposes
		$args['pg_origin'] = $origin_value;
		
		error_log( "PG Origin Plugin: Added pg_origin to query args: {$origin_value}" );
	}
	return $args;
}, 10, 2 );

# Handle the actual SQL modification for Analytics orders
add_filter( 'woocommerce_analytics_clauses_join_orders_subquery', function ( $clauses ) {
	global $pg_current_origin_filter;
	
	// Check multiple sources for the origin parameter
	$origin_value = '';
	if ( ! empty( $pg_current_origin_filter ) ) {
		$origin_value = $pg_current_origin_filter;
	} elseif ( ! empty( $_GET['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_GET['pg_origin'] );
	} elseif ( ! empty( $_REQUEST['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_REQUEST['pg_origin'] );
	}
	
	if ( $origin_value ) {
		global $wpdb;
		$clauses[] = "JOIN {$wpdb->postmeta} origin_postmeta ON {$wpdb->prefix}wc_order_stats.order_id = origin_postmeta.post_id";
		error_log( "PG Origin Plugin: Added JOIN clause for analytics orders: {$origin_value}" );
	}
	return $clauses;
} );

add_filter( 'woocommerce_analytics_clauses_where_orders_subquery', function ( $clauses ) {
	global $pg_current_origin_filter;
	
	// Check multiple sources for the origin parameter
	$origin_value = '';
	if ( ! empty( $pg_current_origin_filter ) ) {
		$origin_value = $pg_current_origin_filter;
	} elseif ( ! empty( $_GET['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_GET['pg_origin'] );
	} elseif ( ! empty( $_REQUEST['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_REQUEST['pg_origin'] );
	}
	
	if ( $origin_value ) {
		$escaped_meta_key = esc_sql( PG_ORIGIN_META_KEY );
		$escaped_origin = esc_sql( $origin_value );
		$clauses[] = "AND origin_postmeta.meta_key = '{$escaped_meta_key}' AND origin_postmeta.meta_value = '{$escaped_origin}'";
		error_log( "PG Origin Plugin: Added WHERE clause for analytics orders: {$origin_value}" );
	}
	return $clauses;
} );

# Also handle orders stats queries
add_filter( 'woocommerce_analytics_orders_stats_query_args', function ( $args, $request ) {
	if ( ! empty( $request['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $request['pg_origin'] );
		$args['pg_origin'] = $origin_value;
		error_log( "PG Origin Plugin: Added pg_origin to stats query args: {$origin_value}" );
	}
	return $args;
}, 10, 2 );

add_filter( 'woocommerce_analytics_clauses_join_orders_stats_total', function ( $clauses ) {
	global $pg_current_origin_filter;
	
	// Check multiple sources for the origin parameter
	$origin_value = '';
	if ( ! empty( $pg_current_origin_filter ) ) {
		$origin_value = $pg_current_origin_filter;
	} elseif ( ! empty( $_GET['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_GET['pg_origin'] );
	} elseif ( ! empty( $_REQUEST['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_REQUEST['pg_origin'] );
	}
	
	if ( $origin_value ) {
		global $wpdb;
		$clauses[] = "JOIN {$wpdb->postmeta} origin_postmeta ON {$wpdb->prefix}wc_order_stats.order_id = origin_postmeta.post_id";
		error_log( "PG Origin Plugin: Added JOIN clause for stats total: {$origin_value}" );
	}
	return $clauses;
} );

add_filter( 'woocommerce_analytics_clauses_where_orders_stats_total', function ( $clauses ) {
	global $pg_current_origin_filter;
	
	// Check multiple sources for the origin parameter
	$origin_value = '';
	if ( ! empty( $pg_current_origin_filter ) ) {
		$origin_value = $pg_current_origin_filter;
	} elseif ( ! empty( $_GET['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_GET['pg_origin'] );
	} elseif ( ! empty( $_REQUEST['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_REQUEST['pg_origin'] );
	}
	
	if ( $origin_value ) {
		$escaped_meta_key = esc_sql( PG_ORIGIN_META_KEY );
		$escaped_origin = esc_sql( $origin_value );
		$clauses[] = "AND origin_postmeta.meta_key = '{$escaped_meta_key}' AND origin_postmeta.meta_value = '{$escaped_origin}'";
		error_log( "PG Origin Plugin: Added WHERE clause for stats total: {$origin_value}" );
	}
	return $clauses;
} );

add_filter( 'woocommerce_analytics_clauses_join_orders_stats_interval', function ( $clauses ) {
	global $pg_current_origin_filter;
	
	// Check multiple sources for the origin parameter
	$origin_value = '';
	if ( ! empty( $pg_current_origin_filter ) ) {
		$origin_value = $pg_current_origin_filter;
	} elseif ( ! empty( $_GET['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_GET['pg_origin'] );
	} elseif ( ! empty( $_REQUEST['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_REQUEST['pg_origin'] );
	}
	
	if ( $origin_value ) {
		global $wpdb;
		$clauses[] = "JOIN {$wpdb->postmeta} origin_postmeta ON {$wpdb->prefix}wc_order_stats.order_id = origin_postmeta.post_id";
		error_log( "PG Origin Plugin: Added JOIN clause for stats interval: {$origin_value}" );
	}
	return $clauses;
} );

add_filter( 'woocommerce_analytics_clauses_where_orders_stats_interval', function ( $clauses ) {
	global $pg_current_origin_filter;
	
	// Check multiple sources for the origin parameter
	$origin_value = '';
	if ( ! empty( $pg_current_origin_filter ) ) {
		$origin_value = $pg_current_origin_filter;
	} elseif ( ! empty( $_GET['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_GET['pg_origin'] );
	} elseif ( ! empty( $_REQUEST['pg_origin'] ) ) {
		$origin_value = sanitize_text_field( $_REQUEST['pg_origin'] );
	}
	
	if ( $origin_value ) {
		$escaped_meta_key = esc_sql( PG_ORIGIN_META_KEY );
		$escaped_origin = esc_sql( $origin_value );
		$clauses[] = "AND origin_postmeta.meta_key = '{$escaped_meta_key}' AND origin_postmeta.meta_value = '{$escaped_origin}'";
		error_log( "PG Origin Plugin: Added WHERE clause for stats interval: {$origin_value}" );
	}
	return $clauses;
} );

# 2 ▸ Enqueue our React snippet + data
add_action( 'admin_enqueue_scripts', function () {
	// Check if we're on WooCommerce Analytics pages
	$current_screen = get_current_screen();
	if ( ! $current_screen || 
		 ( empty( $_GET['page'] ) || strpos( $_GET['page'], 'wc-' ) !== 0 ) &&
		 ( ! $current_screen || strpos( $current_screen->id, 'woocommerce' ) === false ) ) {
		return;
	}

	// Get origins data
	$origins_data = array_map(
		function( $o ) { return [ 'value' => $o, 'label' => $o ]; },
		pg_get_all_origins()
	);

	// Only enqueue if we have origin data
	if ( empty( $origins_data ) ) {
		error_log( 'PG Origin Plugin: No origin data found, not loading analytics filter' );
		return;
	}

	error_log( 'PG Origin Plugin: Enqueuing analytics script for page: ' . ( $_GET['page'] ?? 'unknown' ) );

	/* 2a. Enqueue the correct advanced filter implementation */
	// Main advanced filter (using correct hook from WC docs)
	wp_enqueue_script(
		'pg-origin-advanced-filter',
		plugins_url( 'advanced-filter.js', __FILE__ ),
		[ 'wp-hooks', 'wp-i18n' ],
		'2.5.1',
		true
	);

	// Diagnostic script for troubleshooting
	wp_enqueue_script(
		'pg-origin-diagnostic',
		plugins_url( 'diagnostic.js', __FILE__ ),
		[ 'wp-hooks' ],
		'2.5.1',
		true
	);

	/* 2b. Localize data for the focused scripts */
	$scripts = [ 'pg-origin-advanced-filter', 'pg-origin-diagnostic' ];
	foreach ( $scripts as $script ) {
		wp_localize_script( $script, 'pgOriginData', $origins_data );
	}

	// Add debugging for the advanced filter
	wp_add_inline_script(
		'pg-origin-advanced-filter',
		'console.log("PG Origin Plugin PHP: Advanced filter script enqueued");
		 console.log("PG Origin Plugin PHP: Origins data:", ' . wp_json_encode( $origins_data ) . ');
		 console.log("PG Origin Plugin PHP: Current page:", ' . wp_json_encode( $_GET['page'] ?? 'unknown' ) . ');
		 console.log("PG Origin Plugin PHP: Using CORRECT hook: woocommerce_admin_orders_report_filters");',
		'before'
	);
}, 20 ); // Load after WooCommerce Admin

# Global variable to store the current origin filter value
$pg_current_origin_filter = null;

# Capture the origin parameter from REST API requests
add_action( 'rest_api_init', function() {
	add_filter( 'rest_request_before_callbacks', function( $response, $handler, $request ) {
		global $pg_current_origin_filter;
		
		// Check if this is a WooCommerce Analytics request
		$route = $request->get_route();
		if ( strpos( $route, '/wc-analytics/reports/orders' ) !== false ) {
			$pg_origin = $request->get_param( 'pg_origin' );
			if ( ! empty( $pg_origin ) ) {
				$pg_current_origin_filter = sanitize_text_field( $pg_origin );
				error_log( "PG Origin Plugin: Captured origin from REST API: {$pg_current_origin_filter}" );
			}
		}
		
		return $response;
	}, 10, 3 );
} );
